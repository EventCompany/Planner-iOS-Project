//
//  XLViewController.swift
//  XLProjectName
//
//  Created by XLAuthorName ( XLAuthorWebsite )
//  Copyright © 2016 XLOrganizationName. All rights reserved.
//

import Foundation
import UIKit
import RxCocoa
import RxSwift

class XLViewController: UIViewController {
    let disposeBag = DisposeBag()

}
