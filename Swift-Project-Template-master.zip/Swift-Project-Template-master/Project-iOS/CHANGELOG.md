# Change Log
All notable changes to XLProductName will be documented in this file.

### [1.0.0](https://github.com/XLUserName/XLProductName/releases/tag/1.0.0)
<!-- Released on 2016-01-20. -->

* This is the initial version.

[xmartlabs]: https://xmartlabs.com
